readme.txt of the toolbox_skeleton

Please update this file to provide information about your toolbox:
* what it is doing
* the author
* a few word about the license
